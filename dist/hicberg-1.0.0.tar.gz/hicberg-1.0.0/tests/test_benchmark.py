import pytest



def test_benchmark():
    pass