from os.path import join

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from mpl_toolkits.axes_grid1 import make_axes_locatable

import cooler
import bioframe as bf


def test_plot_laws():
    pass

def test_plot_hic_matrix():
    pass

def test_plot_couple_repartition():
    pass

def test_plot_matrix_detailled():
    pass

def test_plot_matrix():
    pass

def test_plot_differences():
    pass

def test_plot_probability_maps():
    pass

def test_show_results():
    pass