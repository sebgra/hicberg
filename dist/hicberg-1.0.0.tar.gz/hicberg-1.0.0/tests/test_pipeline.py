import glob
from os.path import join
from pathlib import Path
import subprocess as sp

import multiprocessing
from functools import partial
import logging

import numpy as np


def test_check_tools():
    pass

def test_pipeline():
    pass